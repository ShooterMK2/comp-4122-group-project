class_name GenXIASave
extends RefCounted

## JSON saves that survive the things that actually happen: a crash during a write, a save from an older build, a
## file that was never written, and a file someone edited by hand.
##
## Rules this keeps:
##   - writing goes to <path>.tmp first and only replaces the real file once the write succeeded
##   - a missing, empty or corrupt save returns {} plus the reason - it never throws and never crashes the game
##   - every save carries a "version" field so old data can be migrated instead of deleted

const VERSION := 1
const VERSION_KEY := "version"

## Writes data atomically. Returns an error string, or "" on success.
func write(path: String, data: Dictionary) -> String:
	var payload := data.duplicate(true)
	payload[VERSION_KEY] = VERSION
	var text := JSON.stringify(payload, "\t")

	var tmp := path + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return "cannot open %s for writing (error %d)" % [tmp, FileAccess.get_open_error()]
	f.store_string(text)
	f.close()

	# the rename is the atomic step: until it happens, the previous save is still intact
	var dir := path.get_base_dir()
	var err := DirAccess.rename_absolute(tmp, path) if dir != "" else DirAccess.rename_absolute(tmp, path)
	if err != OK:
		# some platforms refuse rename across a directory boundary; fall back to a copy
		var copied := DirAccess.copy_absolute(tmp, path)
		DirAccess.remove_absolute(tmp)
		if copied != OK:
			return "cannot replace %s (error %d)" % [path, copied]
	return ""


## Reads a save. Returns {"data": Dictionary, "ok": bool, "reason": String}.
## A missing file is not an error - it is a new game.
func read(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {"data": {}, "ok": false, "reason": "missing"}
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return {"data": {}, "ok": false, "reason": "unreadable"}
	var text := f.get_as_text()
	f.close()
	if text.strip_edges() == "":
		return {"data": {}, "ok": false, "reason": "empty"}
	var parsed = JSON.parse_string(text)
	if parsed == null or not (parsed is Dictionary):
		return {"data": {}, "ok": false, "reason": "corrupt"}
	return {"data": parsed, "ok": true, "reason": ""}


## Convenience: the data, or an empty Dictionary if anything went wrong.
func read_or_empty(path: String) -> Dictionary:
	return read(path)["data"]


## The version stored in a payload, or 0 when there is none.
func version_of(data: Dictionary) -> int:
	return int(data.get(VERSION_KEY, 0))


## Migrates older payloads forward. Add a step per version bump; unknown future versions are returned untouched
## rather than downgraded, because losing a player's save is worse than running with extra fields.
func migrate(data: Dictionary) -> Dictionary:
	var out := data.duplicate(true)
	var v := version_of(out)
	if v == 0:
		# pre-versioning save: assume v1 shape
		v = 1
		out[VERSION_KEY] = 1
	if v > VERSION:
		return out
	# no migrations to run while VERSION is 1
	return out


func delete(path: String) -> bool:
	if not FileAccess.file_exists(path):
		return false
	return DirAccess.remove_absolute(path) == OK
