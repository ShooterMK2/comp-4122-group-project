extends SceneTree

## Exercises the save layer against the cases that break saves: missing file, empty file, corrupt file, older save,
## and a write that must not destroy the previous good save.

const DIR := "user://gen_xia_save_test"

var lines: Array = []
var failures: int = 0


func _check(name: String, ok: bool, detail: String = "") -> void:
	lines.append("%s %s %s" % ["PASS" if ok else "FAIL", name, detail])
	if not ok:
		failures += 1


func _init() -> void:
	DirAccess.make_dir_recursive_absolute(DIR)
	var save = load("res://save_system.gd").new()
	var path := DIR + "/slot1.json"

	# 1. missing file is not an error, it is a new game
	var r = save.read(path)
	_check("missing save reports missing", r["ok"] == false and r["reason"] == "missing", r["reason"])

	# 2. round trip
	var err = save.write(path, {"coins": 42, "level": 7})
	var r2 = save.read(path)
	_check("round trip", err == "" and r2["ok"] and int(r2["data"]["coins"]) == 42,
		"err=%s coins=%s" % [err, str(r2["data"].get("coins"))])

	# 3. version is stamped on write
	_check("version stamped", int(r2["data"]["version"]) == 1, "v=%s" % str(r2["data"].get("version")))

	# 4. overwriting keeps the file valid and the newest values
	save.write(path, {"coins": 99, "level": 8})
	var r3 = save.read(path)
	_check("overwrite replaces cleanly", int(r3["data"]["coins"]) == 99, "coins=%s" % str(r3["data"].get("coins")))

	# 5. an empty file is reported, not parsed into garbage
	var empty_path := DIR + "/empty.json"
	var ef := FileAccess.open(empty_path, FileAccess.WRITE)
	ef.store_string("")
	ef.close()
	var r4 = save.read(empty_path)
	_check("empty file reported", r4["ok"] == false and r4["reason"] == "empty", r4["reason"])

	# 6. a corrupt file is reported and does not crash
	var bad_path := DIR + "/bad.json"
	var bf := FileAccess.open(bad_path, FileAccess.WRITE)
	bf.store_string("{not json at all,,,")
	bf.close()
	var r5 = save.read(bad_path)
	_check("corrupt file reported", r5["ok"] == false and r5["reason"] == "corrupt", r5["reason"])

	# 7. a pre-versioning save migrates instead of being discarded
	var old_path := DIR + "/old.json"
	var of := FileAccess.open(old_path, FileAccess.WRITE)
	of.store_string('{"coins": 5, "level": 2}')
	of.close()
	var r6 = save.read(old_path)
	var migrated = save.migrate(r6["data"])
	_check("old save migrates", save.version_of(migrated) == 1 and int(migrated["coins"]) == 5,
		"v=%d coins=%s" % [save.version_of(migrated), str(migrated.get("coins"))])

	# 8. a newer save is passed through rather than downgraded
	var future = save.migrate({"version": 99, "coins": 1})
	_check("future save not downgraded", int(future["version"]) == 99, "v=%s" % str(future.get("version")))

	# 9. a failed write must leave the previous save intact - simulated by writing to a path in a folder that
	#    does not exist, then confirming the good save still reads back
	var bad_target := DIR + "/no_such_folder/slot.json"
	var werr = save.write(bad_target, {"coins": 1})
	var still = save.read(path)
	_check("failed write leaves old save intact", werr != "" and still["ok"] and int(still["data"]["coins"]) == 99,
		"werr=%s old ok=%s" % [werr, str(still["ok"])])

	# 10. delete removes it and a second delete reports nothing to do
	save.delete(path)
	var after = save.read(path)
	_check("delete then read reports missing", after["ok"] == false and after["reason"] == "missing",
		after["reason"])

	lines.append("failures: %d" % failures)
	lines.append("save system ok: %s" % str(failures == 0))
	var f := FileAccess.open("res://_test-result.txt", FileAccess.WRITE)
	for l in lines:
		f.store_line(l)
	f.close()
	quit(0 if failures == 0 else 1)
