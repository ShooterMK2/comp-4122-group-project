extends Node2D

## Two buttons' worth of state, saved and loaded through GenXIASave.

const PATH := "user://gen_xia_demo_save.json"

var save := GenXIASave.new()
var coins := 0
var level := 1
var _status: Label


func _ready() -> void:
	var bg := ColorRect.new()
	bg.color = Color(0.09, 0.08, 0.12)
	bg.size = Vector2(576, 384)
	add_child(bg)

	var box := VBoxContainer.new()
	box.position = Vector2(24, 24)
	box.add_theme_constant_override("separation", 10)
	add_child(box)

	for spec in [["F1  add 25 coins", func(): coins += 25; _refresh()],
			["F2  level up", func(): level += 1; _refresh()],
			["F3  save", func(): _save()],
			["F4  load", func(): _load()],
			["F5  delete save", func(): save.delete(PATH); _status.text = "save deleted"; _refresh()]]:
		var b := Button.new()
		b.text = spec[0]
		b.pressed.connect(spec[1])
		box.add_child(b)

	_status = Label.new()
	box.add_child(_status)
	_refresh()


func _refresh() -> void:
	_status.text = "coins %d   level %d" % [coins, level]


func _save() -> void:
	var err := save.write(PATH, {"coins": coins, "level": level})
	_status.text = "saved" if err == "" else "save failed: " + err


func _load() -> void:
	var result := save.read(PATH)
	if not result["ok"]:
		_status.text = "nothing to load (%s)" % result["reason"]
		return
	var data := save.migrate(result["data"])
	coins = int(data.get("coins", 0))
	level = int(data.get("level", 1))
	_status.text = "loaded v%d save" % save.version_of(data)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_F1: coins += 25; _refresh()
			KEY_F2: level += 1; _refresh()
			KEY_F3: _save()
			KEY_F4: _load()
