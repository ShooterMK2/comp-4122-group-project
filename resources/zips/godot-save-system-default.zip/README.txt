Gen XIA Save System for Godot 4
==============================

JSON saves with a version field, atomic writes, and sensible behaviour when the file is not what you expect.

What it actually protects you from
----------------------------------
Not "how do I write JSON". These:

  **a crash during a write**      the save is written to <path>.tmp and only renamed over the real file afterwards,
                                  so a process killed mid-write cannot destroy the previous good save
  **a save from an older build**  every payload carries a version number; migrate() upgrades old ones instead of
                                  silently discarding a player's progress
  **a save from a newer build**   passed through untouched rather than downgraded - losing data is worse than seeing
                                  extra fields
  **an empty or corrupt file**    reported as {"ok": false, "reason": "corrupt"} instead of crashing the game
  **a file that was never there** reported as "missing", which is a new game, not an error

API
---
  var save := GenXIASave.new()
  var err := save.write("user://slot1.json", {"coins": 42, "level": 7})   # "" on success
  var result := save.read("user://slot1.json")                            # {data, ok, reason}
  var data := save.read_or_empty("user://slot1.json")                     # just the data
  var data2 := save.migrate(data)                                         # upgrade old versions
  save.delete("user://slot1.json")

Files
-----
  save_system.gd     GenXIASave
  demo.gd / demo.tscn  a window where F1-F5 add coins, save, load and delete
  test_save.gd       10 assertions

Tested
------
    godot --headless --path . --script res://test_save.gd

Last run: 10 assertions, 0 failures. It covers the round trip, version stamping, overwriting, empty files, corrupt
files, migrating a pre-versioning save, passing through a future save, and confirming that a **failed write leaves
the previous save readable** - the one case a save system is really for.

Licence
-------
Commercial use in your own games, including released titles. Not for resale or redistribution as an asset pack.
